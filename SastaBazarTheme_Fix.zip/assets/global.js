// Global Javascript file for Shopify Theme
document.addEventListener('DOMContentLoaded', () => {
    console.log('Sasta Bazar PK Theme successfully loaded!');
});
